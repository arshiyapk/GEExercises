package com.ge.exercise4;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class GENxTest {

    GENx testEngine;

    @Before
    public void setUp() {
        testEngine = new GENx("0001");
        testEngine = new GENx("0001",35_000,0);
    }

    @Test
    public void toStringTest() {
        assertEquals("GENx SN: 0001", testEngine.toString());
    }

    @Test
    public void thrustToWeightRatioTest() {
        assertEquals(testEngine.takeoffThrust / testEngine.dryWeight, testEngine.thrustToWeightRatio(), 0.01);
    }
    @Test
    public void hoursLeftBeforeRebuildTest() {
        assertEquals(Math.abs(testEngine.flightHoursBeforeRebuild - testEngine.getFlightHours()), testEngine.hoursLeftBeforeRebuild(), 0.01);
    }
    @Test
    public void serviceLifeOfFlightTest() {
        assertEquals((testEngine.maxNumRebuilds*testEngine.flightHoursBeforeRebuild)-(testEngine.getFlightHours()*2), testEngine.serviceLifeOfFlight(), 0.01);
    }
}