package com.ge.exercise4;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class GE90Test {

    GE90 testEngine;

    @Before
    public void setUp() {
        testEngine = new GE90("0001");
        testEngine = new GE90("0001",35_000,0);
    }

    @Test
    public void toStringTest() {
        assertEquals("GE90 SN: 0001", testEngine.toString());
    }

    @Test
    public void thrustToWeightRatioTest() {
        assertEquals(testEngine.takeoffThrust / testEngine.dryWeight, testEngine.thrustToWeightRatio(), 0.01);
    }
    @Test
    public void hoursLeftBeforeRebuildTest() {
        assertEquals(Math.abs(testEngine.flightHoursBeforeRebuild - testEngine.getFlightHours()), testEngine.hoursLeftBeforeRebuild(), 0.01);
    }
    @Test
    public void serviceLifeOfFlightTest() {
        assertEquals((testEngine.maxNumRebuilds*testEngine.flightHoursBeforeRebuild)-(testEngine.getFlightHours()*2), testEngine.serviceLifeOfFlight(), 0.01);
    }
}