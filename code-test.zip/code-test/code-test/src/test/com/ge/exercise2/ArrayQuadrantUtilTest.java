package com.ge.exercise2;

import org.junit.Assume;
import org.junit.Test;

import static org.junit.Assert.assertArrayEquals;

public class ArrayQuadrantUtilTest {

    @Test
    public void getQuadrantValuesTest() {
        Object[][] data = {
                {'a', 'b', 'c', 'd'},
                {'e', 'f', 'g', 'h'},
                {'i', 'j', 'k', 'l'},
                {'m', 'n', 'o', 'p'}
        };

        ArrayQuadrantUtil util = new ArrayQuadrantUtil(data);
        Assume.assumeNotNull(util.getQuadrantValues(1, 0));
        Object[] expectedResult = {'k', 'l', 'o', 'p'};
        assertArrayEquals(expectedResult, util.getQuadrantValues(1, 1));
    }
    @Test
    public void getRowValuesTest() {
        Object[][] data = {
                {1, 'b', 'c', 'd'},
                {1, 'f', 'g', 'h'},
                {'i', 'j', 'k', 'l'},
                {'m', 'n', 'o', 'p'}
        };

        ArrayQuadrantUtil util = new ArrayQuadrantUtil(data);
        Assume.assumeNotNull(util.getRows(1));
        Object[] expectedResult = {1, 'f', 'g', 'h'};
        assertArrayEquals(expectedResult, util.getRows(1));
    }
    @Test
    public void getColumnValuesTest() {
    	Object[][] data = {
                {1, 'b', 'c', 'd'},
                {'e', 'f', 'g', 'h'},
                {'i', 'j', 'k', 'l'},
                {'m', 'n', 'o', 'p'}
        };

        ArrayQuadrantUtil util = new ArrayQuadrantUtil(data);
        Assume.assumeNotNull(util.getColumns(0));
        Object[] expectedResult = {1, 'e', 'i', 'm'};
        assertArrayEquals(expectedResult, util.getColumns(0));
    }
}