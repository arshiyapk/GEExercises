package com.ge.exercise5;

public enum ItemType {NORMAL, AGEABLE, PRECIOUS, RARE, PERISHABLE}
