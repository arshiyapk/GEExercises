package com.ge.exercise2;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ArrayQuadrantUtil {
    private static final Logger logger = LogManager.getLogger(ArrayQuadrantUtil.class);

    Object[][] data;

    public ArrayQuadrantUtil(Object[][] data) {
        this.data = data;
    }
    public Object[] getRows(int row) {
    	 return this.data[row];
    }
    public Object[] getColumns(int column) {
            Object[] columnArray = new Object[data.length];
    	for(int row=0;row<data.length;row++){
    		
			columnArray[row]=data[row][column];
			
    	}
    	return columnArray; 
    }

    public Object[] getQuadrantValues(int row, int column) {
    	int len=this.data.length;
    	Object[] quad = new Object[len];
    	ArrayList<Object> arr = new ArrayList<Object>();
    	if( row==0 && column==0){
    		for (int i=0;i<len/2;i++){
        		for (int j=0;j<len/2;j++){
        			Object num =this.data[i][j];
        			arr.add(num);
        		}
        	}
    	}
    	else if( row==0 && column==1){
    		for (int i=0;i<len/2;i++){
        		for (int j=(len/2);j<len;j++){
        			Object num =this.data[i][j];
        			arr.add(num);
        		}
        		
        	}
    	}
    	else if( row==1 && column==0){
    		for (int i=len/2;i<len;i++){
        		for (int j=0;j<len/2;j++){
        			Object num =this.data[i][j];
        			arr.add(num);
        		}
        		
        	}
    	}
    	else{
    		for (int i=len/2;i<len;i++){
        		for (int j=len/2;j<len;j++){
        			Object num =this.data[i][j];
        			arr.add(num);
        		}
        		
        	}
    	}
    	for ( int k=0;k<arr.size();k++){
    		quad[k]=arr.get(k);
    	}
        return quad;
    }
}
