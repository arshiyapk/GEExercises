package com.ge.exercise1;

public interface Parser {
    Application parseApplicationData(String data);
}
